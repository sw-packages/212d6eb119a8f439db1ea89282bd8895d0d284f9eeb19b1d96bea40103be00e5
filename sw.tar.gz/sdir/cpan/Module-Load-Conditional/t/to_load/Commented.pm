package Commented;
use strict;

our $VERSION;
# $VERSION = 1;
$VERSION = 2;

1;
